RAMAL RH - VERSÃO HTML / GITHUB PAGES

1. Crie um repositório no GitHub.
2. Envie o arquivo index.html para o repositório.
3. Vá em Settings > Pages.
4. Em Source, escolha Deploy from a branch.
5. Escolha a branch main e a pasta /root.
6. Salve e abra o endereço fornecido pelo GitHub.

Como usar:
- Abra o site no PC.
- Carregue seu TXT de telefones.
- Clique em Próximo número.
- O QR Code será atualizado com o número atual.
- Escaneie o QR com o celular.
- No celular, toque em LIGAR PARA O NÚMERO.

Esta versão é totalmente estática: não precisa de Python, servidor local ou instalação.
Os dados da fila ficam salvos somente no navegador do PC.
